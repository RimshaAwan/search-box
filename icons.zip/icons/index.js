function changebg(){
    let  navbar=document.getElementById('navbar');
    let scrollValue = window.scrollY;
    let sr=document.getElementById("sea");
    let phn=document.getElementById("ph");
    
    if(scrollValue > 200){
        navbar.classList.add('bgcol');
        sr.classList.add("sicon");
        phn.classList.add("picon");
        document.getElementById("whitelogo").src="./down.jpeg"
        
    }else{
        navbar.classList.remove('bgcol');
        sr.classList.remove("sicon");
        phn.classList.remove("picon");
        document.getElementById("whitelogo").src="./up.jpeg"
        
    }
}

window.addEventListener('scroll', changebg);



let show=document.getElementById("sea");



show.addEventListener('mouseover', function(){

    document.getElementById("search").style.display="block"
   });


   let close=document.getElementById("close");
   close.addEventListener('click', function(){

    document.getElementById("search").style.display="none"
   });






   
   let icon=document.getElementById("icon");

   icon.onmouseover=function(){

    document.getElementById("message").style.display="block"
    document.getElementById("whattsapp").style.display="block"
   }

   icon.addEventListener('click', function(){

    document.getElementById("message").style.display="none"
    document.getElementById("whattsapp").style.display="none"
   });